import { siteData } from '../data/siteData'

function About() {
  const { about } = siteData

  return (
    <section id="nosotros" className="bg-white py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid gap-14 lg:grid-cols-[0.95fr_1.05fr] lg:items-center">
          <div>
            <p className="section-eyebrow">{about.eyebrow}</p>
            <h2 className="section-title mt-3">{about.title}</h2>

            <div className="mt-7 space-y-5 text-base leading-8 text-slate-600">
              {about.description.map((paragraph) => (
                <p key={paragraph}>{paragraph}</p>
              ))}
            </div>

            <div className="mt-8 grid gap-3 sm:grid-cols-2">
              {about.highlights.map((item) => (
                <div
                  key={item}
                  className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm font-semibold text-slate-700"
                >
                  <span className="mr-2 text-cyan-700">✓</span>
                  {item}
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-[2rem] border border-slate-200 bg-slate-50 p-6 shadow-sm">
            <div className="rounded-[1.5rem] bg-slate-950 p-6 text-white">
              <p className="text-sm font-bold uppercase tracking-[0.25em] text-cyan-300">
                Equipo
              </p>

              <div className="mt-7 grid gap-4">
                {about.team.map((member) => (
                  <div
                    key={member.name}
                    className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.04] p-4"
                  >
                    <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-cyan-400/15 text-sm font-black text-cyan-300">
                      {member.initials}
                    </div>

                    <div>
                      <h3 className="font-bold text-white">{member.name}</h3>
                      <p className="mt-1 text-sm text-slate-400">
                        {member.role}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 rounded-2xl border border-dashed border-white/15 bg-white/[0.03] p-6 text-center">
                <p className="text-sm font-semibold text-slate-300">
                  Espacio para fotografía del equipo
                </p>
                <p className="mt-2 text-xs text-slate-500">
                  Se reemplaza cuando tengan una foto corporativa real.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default About