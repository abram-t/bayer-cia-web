import { siteData } from '../data/siteData'

function Clients() {
  const { clients, allies } = siteData

  return (
    <section id="clientes" className="bg-slate-950 py-24 text-white">
      <div className="mx-auto max-w-7xl px-6">
        <div className="max-w-3xl">
          <p className="section-eyebrow text-cyan-300">{clients.eyebrow}</p>
          <h2 className="mt-3 text-3xl font-black tracking-tight text-white sm:text-4xl lg:text-5xl">
            {clients.title}
          </h2>
          <p className="mt-5 max-w-2xl text-lg leading-8 text-slate-400">
            {clients.description}
          </p>
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {clients.items.map((client) => (
            <div
              key={client}
              className="flex min-h-28 items-center justify-center rounded-3xl border border-white/10 bg-white/[0.04] p-5 text-center text-sm font-bold text-slate-200 transition hover:border-cyan-300/40 hover:bg-cyan-300/10"
            >
              {client}
            </div>
          ))}
        </div>

        <div className="mt-20 rounded-[2rem] border border-white/10 bg-white/[0.04] p-8">
          <p className="section-eyebrow text-cyan-300">{allies.eyebrow}</p>
          <div className="mt-3 grid gap-8 lg:grid-cols-[0.8fr_1.2fr] lg:items-center">
            <div>
              <h3 className="text-2xl font-black text-white">
                {allies.title}
              </h3>
              <p className="mt-4 leading-7 text-slate-400">
                {allies.description}
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              {allies.items.map((ally) => (
                <div
                  key={ally}
                  className="rounded-2xl border border-dashed border-white/15 bg-slate-950/40 p-5 text-center text-sm font-semibold text-slate-300"
                >
                  {ally}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Clients