import { siteData } from '../data/siteData'

function QuoteForm() {
  const { quote, company } = siteData

  return (
    <section id="cotizar" className="bg-slate-50 py-24">
      <div className="mx-auto grid max-w-7xl gap-12 px-6 lg:grid-cols-[0.9fr_1.1fr]">
        <div>
          <p className="section-eyebrow">{quote.eyebrow}</p>
          <h2 className="section-title mt-3">{quote.title}</h2>
          <p className="section-description mt-5">{quote.description}</p>

          <div className="mt-8 rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
            <h3 className="text-lg font-black text-slate-950">
              Contacto directo
            </h3>
            <p className="mt-3 text-slate-600">
              También puedes escribir directamente por correo o WhatsApp.
            </p>

            <div className="mt-6 space-y-3 text-sm font-semibold text-slate-700">
              <p>Correo: {company.email}</p>
              <p>WhatsApp: {company.phone}</p>
              <p>Cobertura: {company.location}</p>
            </div>

            <a
              href={`https://wa.me/${company.whatsapp}`}
              target="_blank"
              rel="noreferrer"
              className="mt-7 inline-flex rounded-full bg-slate-950 px-6 py-3 text-sm font-bold text-white transition hover:bg-cyan-700"
            >
              Escribir por WhatsApp
            </a>
          </div>
        </div>

        <form
          action={quote.formspreeEndpoint}
          method="POST"
          className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-xl sm:p-8"
        >
          <div className="grid gap-5 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="form-label" htmlFor="name">
                Nombre completo *
              </label>
              <input
                className="form-input"
                id="name"
                name="Nombre completo"
                type="text"
                placeholder="Juan Pérez"
                required
              />
            </div>

            <div>
              <label className="form-label" htmlFor="company">
                Empresa / Institución *
              </label>
              <input
                className="form-input"
                id="company"
                name="Empresa o institución"
                type="text"
                placeholder="Nombre de tu empresa"
                required
              />
            </div>

            <div>
              <label className="form-label" htmlFor="email">
                Correo electrónico *
              </label>
              <input
                className="form-input"
                id="email"
                name="Correo electrónico"
                type="email"
                placeholder="juan@empresa.cl"
                required
              />
            </div>

            <div>
              <label className="form-label" htmlFor="country">
                País / Ubicación *
              </label>
              <input
                className="form-input"
                id="country"
                name="País o ubicación"
                type="text"
                placeholder="Chile"
                required
              />
            </div>

            <div>
              <label className="form-label" htmlFor="equipment">
                Equipo o modelo con falla *
              </label>
              <input
                className="form-input"
                id="equipment"
                name="Equipo o modelo"
                type="text"
                placeholder="Ej: Espectrómetro XRF modelo..."
                required
              />
            </div>

            <div className="sm:col-span-2">
              <label className="form-label" htmlFor="message">
                Descripción del problema *
              </label>
              <textarea
                className="form-input min-h-36 resize-y"
                id="message"
                name="Descripción del problema"
                placeholder="Describe el problema o la necesidad técnica de tu laboratorio..."
                required
              />
            </div>
          </div>

          <button
            type="submit"
            className="mt-7 w-full rounded-full bg-cyan-600 px-7 py-4 text-sm font-black text-white transition hover:bg-cyan-700"
          >
            Enviar solicitud
          </button>

          <p className="mt-4 text-center text-xs text-slate-500">
            El formulario quedará activo cuando se reemplace el endpoint de
            Formspree.
          </p>
        </form>
      </div>
    </section>
  )
}

export default QuoteForm