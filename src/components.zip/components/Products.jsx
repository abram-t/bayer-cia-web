import { siteData } from '../data/siteData'

function Products() {
  const { products } = siteData

  return (
    <section id="productos" className="bg-white py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:items-end">
          <div>
            <p className="section-eyebrow">{products.eyebrow}</p>
            <h2 className="section-title mt-3">{products.title}</h2>
          </div>

          <p className="section-description lg:max-w-2xl">
            {products.description}
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {products.items.map((product) => (
            <article
              key={product.name}
              className="overflow-hidden rounded-[2rem] border border-slate-200 bg-slate-50 shadow-sm"
            >
              <div className="flex aspect-[4/3] items-center justify-center bg-gradient-to-br from-slate-900 to-slate-700 p-6">
                <div className="rounded-2xl border border-dashed border-cyan-300/30 bg-white/5 px-6 py-8 text-center">
                  <p className="text-xs font-bold uppercase tracking-[0.25em] text-cyan-300">
                    Imagen producto
                  </p>
                  <p className="mt-3 text-sm text-slate-300">
                    Foto pendiente
                  </p>
                </div>
              </div>

              <div className="p-7">
                <h3 className="text-xl font-black text-slate-950">
                  {product.name}
                </h3>
                <p className="mt-3 leading-7 text-slate-600">
                  {product.description}
                </p>
                <p className="mt-5 rounded-2xl bg-white px-4 py-3 text-sm font-semibold text-slate-700 ring-1 ring-slate-200">
                  {product.measures}
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Products