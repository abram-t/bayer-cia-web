import { siteData } from '../data/siteData'

function Footer() {
  const { company, navigation } = siteData
  const currentYear = new Date().getFullYear()

  return (
    <footer id="contacto" className="bg-slate-950 text-white">
      <div className="mx-auto max-w-7xl px-6 py-14">
        <div className="grid gap-10 lg:grid-cols-[1fr_0.7fr_0.7fr]">
          <div>
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-cyan-400/15 text-sm font-black text-cyan-300 ring-1 ring-cyan-400/30">
                B&C
              </span>
              <div>
                <h2 className="font-black text-white">{company.name}</h2>
                <p className="mt-1 text-sm text-slate-400">
                  {company.tagline}
                </p>
              </div>
            </div>

            <p className="mt-6 max-w-lg leading-7 text-slate-400">
              Servicio técnico, mantención y venta de insumos para laboratorios
              mineralógicos y geológicos en Chile y Latinoamérica.
            </p>
          </div>

          <div>
            <h3 className="font-bold text-white">Navegación</h3>
            <div className="mt-5 grid gap-3">
              {navigation.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  className="text-sm text-slate-400 transition hover:text-cyan-300"
                >
                  {item.label}
                </a>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-bold text-white">Contacto</h3>
            <div className="mt-5 space-y-3 text-sm text-slate-400">
              <p>{company.email}</p>
              <p>{company.phone}</p>
              <p>{company.location}</p>
            </div>
          </div>
        </div>

        <div className="mt-12 border-t border-white/10 pt-6 text-sm text-slate-500">
          {company.name} © {company.foundedYear}–{currentYear} · Servicio técnico
          de laboratorio · Chile y Latinoamérica
        </div>
      </div>
    </footer>
  )
}

export default Footer