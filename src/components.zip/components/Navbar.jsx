import { useState } from 'react'
import { siteData } from '../data/siteData'

function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const { company, navigation } = siteData

  const closeMenu = () => setIsOpen(false)

  return (
    <header className="fixed left-0 top-0 z-50 w-full border-b border-white/10 bg-slate-950/90 text-white backdrop-blur-xl">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <a href="#" onClick={closeMenu} className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500/15 text-sm font-black text-cyan-300 ring-1 ring-cyan-400/30">
            B&C
          </span>

          <span>
            <span className="block text-sm font-bold tracking-wide text-white">
              {company.name}
            </span>
            <span className="hidden text-xs text-slate-400 sm:block">
              {company.tagline}
            </span>
          </span>
        </a>

        <div className="hidden items-center gap-7 lg:flex">
          {navigation.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className="text-sm font-medium text-slate-300 transition hover:text-cyan-300"
            >
              {item.label}
            </a>
          ))}
        </div>

        <div className="hidden items-center gap-3 lg:flex">
          <a
            href={`https://wa.me/${company.whatsapp}`}
            target="_blank"
            rel="noreferrer"
            className="rounded-full border border-white/15 px-5 py-2.5 text-sm font-semibold text-white transition hover:border-cyan-300 hover:text-cyan-300"
          >
            WhatsApp
          </a>

          <a
            href="#cotizar"
            className="rounded-full bg-cyan-400 px-5 py-2.5 text-sm font-bold text-slate-950 transition hover:bg-cyan-300"
          >
            Cotizar
          </a>
        </div>

        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-white/15 text-white lg:hidden"
          aria-label="Abrir menú"
        >
          <span className="text-xl">{isOpen ? '×' : '☰'}</span>
        </button>
      </nav>

      {isOpen && (
        <div className="border-t border-white/10 bg-slate-950 px-6 py-5 lg:hidden">
          <div className="flex flex-col gap-4">
            {navigation.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={closeMenu}
                className="text-sm font-medium text-slate-300"
              >
                {item.label}
              </a>
            ))}

            <a
              href="#cotizar"
              onClick={closeMenu}
              className="mt-2 rounded-full bg-cyan-400 px-5 py-3 text-center text-sm font-bold text-slate-950"
            >
              Solicitar cotización
            </a>
          </div>
        </div>
      )}
    </header>
  )
}

export default Navbar