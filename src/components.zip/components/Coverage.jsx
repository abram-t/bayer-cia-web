import { siteData } from '../data/siteData'

function Coverage() {
  const { coverage } = siteData

  return (
    <section id="cobertura" className="bg-white py-24">
      <div className="mx-auto grid max-w-7xl gap-12 px-6 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
        <div>
          <p className="section-eyebrow">{coverage.eyebrow}</p>
          <h2 className="section-title mt-3">{coverage.title}</h2>
          <p className="section-description mt-5">{coverage.description}</p>

          <div className="mt-8 flex flex-wrap gap-3">
            {coverage.countries.map((country) => (
              <span
                key={country}
                className="rounded-full border border-slate-200 bg-slate-50 px-5 py-2.5 text-sm font-bold text-slate-700"
              >
                {country}
              </span>
            ))}
          </div>
        </div>

        <div className="rounded-[2rem] border border-slate-200 bg-slate-50 p-6 shadow-sm">
          <div className="relative min-h-80 overflow-hidden rounded-[1.5rem] bg-slate-950 p-8 text-white">
            <div className="absolute left-10 top-10 h-28 w-28 rounded-full bg-cyan-400/20 blur-2xl" />
            <div className="absolute bottom-8 right-8 h-40 w-40 rounded-full bg-blue-500/20 blur-3xl" />

            <div className="relative">
              <p className="text-xs font-bold uppercase tracking-[0.25em] text-cyan-300">
                Mapa referencial
              </p>

              <div className="mt-10 grid gap-4">
                {coverage.countries.map((country, index) => (
                  <div
                    key={country}
                    className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/[0.04] px-5 py-4"
                  >
                    <span className="font-semibold text-slate-200">
                      {country}
                    </span>
                    <span className="h-3 w-3 rounded-full bg-cyan-300 shadow-lg shadow-cyan-400/40" />
                  </div>
                ))}
              </div>

              <p className="mt-8 text-sm leading-6 text-slate-400">
                Este bloque puede reemplazarse más adelante por un mapa real o
                una imagen corporativa de cobertura internacional.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Coverage