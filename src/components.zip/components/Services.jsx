import { siteData } from '../data/siteData'

function Services() {
  const { services } = siteData

  return (
    <section id="servicios" className="bg-slate-50 py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="max-w-3xl">
          <p className="section-eyebrow">{services.eyebrow}</p>
          <h2 className="section-title mt-3">{services.title}</h2>
          <p className="section-description mt-5">{services.description}</p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {services.items.map((service, index) => (
            <article
              key={service.title}
              className="group rounded-[2rem] border border-slate-200 bg-white p-7 shadow-sm transition hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="mb-8 flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-950 text-lg font-black text-cyan-300">
                0{index + 1}
              </div>

              <h3 className="text-xl font-black text-slate-950">
                {service.title}
              </h3>

              <p className="mt-4 leading-7 text-slate-600">
                {service.description}
              </p>

              <div className="mt-7 h-1 w-16 rounded-full bg-cyan-500 transition group-hover:w-24" />
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Services