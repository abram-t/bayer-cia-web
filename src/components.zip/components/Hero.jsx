import { siteData } from '../data/siteData'

function Hero() {
  const { hero } = siteData

  return (
    <section className="relative overflow-hidden bg-slate-950 pt-24 text-white">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_rgba(34,211,238,0.18),_transparent_35%),linear-gradient(135deg,_rgba(15,23,42,1),_rgba(2,6,23,1))]" />
      <div className="absolute left-0 top-32 h-72 w-72 rounded-full bg-cyan-400/10 blur-3xl" />
      <div className="absolute bottom-0 right-0 h-96 w-96 rounded-full bg-blue-500/10 blur-3xl" />

      <div className="relative mx-auto grid min-h-[calc(100vh-6rem)] max-w-7xl items-center gap-14 px-6 py-20 lg:grid-cols-[1.08fr_0.92fr]">
        <div>
          <p className="mb-5 inline-flex rounded-full border border-cyan-300/20 bg-cyan-300/10 px-4 py-2 text-xs font-bold uppercase tracking-[0.25em] text-cyan-200">
            {hero.eyebrow}
          </p>

          <h1 className="max-w-4xl text-4xl font-black tracking-tight text-white sm:text-5xl lg:text-7xl">
            {hero.title}
          </h1>

          <p className="mt-7 max-w-2xl text-lg leading-8 text-slate-300">
            {hero.description}
          </p>

          <div className="mt-9 flex flex-col gap-4 sm:flex-row">
            <a
              href={hero.primaryButton.href}
              className="inline-flex items-center justify-center rounded-full bg-cyan-400 px-7 py-3.5 text-sm font-black text-slate-950 shadow-lg shadow-cyan-950/30 transition hover:bg-cyan-300"
            >
              {hero.primaryButton.label}
            </a>

            <a
              href={hero.secondaryButton.href}
              className="inline-flex items-center justify-center rounded-full border border-white/15 px-7 py-3.5 text-sm font-bold text-white transition hover:border-cyan-300 hover:text-cyan-200"
            >
              {hero.secondaryButton.label}
            </a>
          </div>

          <div className="mt-12 grid gap-4 sm:grid-cols-3">
            {hero.stats.map((stat) => (
              <div
                key={stat.label}
                className="rounded-2xl border border-white/10 bg-white/[0.04] p-5 backdrop-blur"
              >
                <p className="text-3xl font-black text-white">{stat.value}</p>
                <p className="mt-2 text-sm leading-5 text-slate-400">
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="relative">
          <div className="absolute -inset-4 rounded-[2rem] bg-cyan-400/10 blur-2xl" />

          <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.06] p-5 shadow-2xl backdrop-blur">
            <div className="rounded-[1.5rem] border border-white/10 bg-slate-900 p-6">
              <div className="mb-6 flex items-center justify-between border-b border-white/10 pb-5">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.22em] text-cyan-300">
                    Laboratorio técnico
                  </p>
                  <p className="mt-2 text-xl font-bold text-white">
                    Diagnóstico especializado
                  </p>
                </div>

                <span className="rounded-full bg-emerald-400/10 px-3 py-1 text-xs font-bold text-emerald-300">
                  Activo
                </span>
              </div>

              <div className="grid gap-4">
                <div className="rounded-2xl bg-slate-800/80 p-5">
                  <p className="text-sm font-semibold text-slate-300">
                    Servicio técnico
                  </p>
                  <div className="mt-4 h-3 rounded-full bg-slate-700">
                    <div className="h-3 w-10/12 rounded-full bg-cyan-400" />
                  </div>
                </div>

                <div className="rounded-2xl bg-slate-800/80 p-5">
                  <p className="text-sm font-semibold text-slate-300">
                    Mantención preventiva
                  </p>
                  <div className="mt-4 h-3 rounded-full bg-slate-700">
                    <div className="h-3 w-8/12 rounded-full bg-blue-400" />
                  </div>
                </div>

                <div className="rounded-2xl bg-slate-800/80 p-5">
                  <p className="text-sm font-semibold text-slate-300">
                    Insumos de laboratorio
                  </p>
                  <div className="mt-4 h-3 rounded-full bg-slate-700">
                    <div className="h-3 w-9/12 rounded-full bg-teal-300" />
                  </div>
                </div>
              </div>

              <div className="mt-6 rounded-2xl border border-dashed border-cyan-300/30 bg-cyan-300/5 p-6 text-center">
                <p className="text-sm font-bold uppercase tracking-[0.2em] text-cyan-300">
                  Espacio para imagen real
                </p>
                <p className="mt-3 text-sm text-slate-400">
                  Aquí podemos colocar una foto de laboratorio, equipo técnico,
                  instrumento o producto real.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Hero